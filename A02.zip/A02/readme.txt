
Talal El Afchal

For this assignment I collaborate with Jesper and Jacques.

I didn't have enough time to implement the VLB, I did only the shortest path.

You can check my chart bar in BarChart.html file


